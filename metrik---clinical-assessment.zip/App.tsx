import React, { useState } from 'react';
import { Screen } from './types';
import { LoginScreen } from './screens/LoginScreen';
import { DashboardScreen } from './screens/DashboardScreen';
import { AssessmentScreen } from './screens/AssessmentScreen';
import { ResultsScreen } from './screens/ResultsScreen';
import { ScheduleScreen } from './screens/ScheduleScreen';
import { BottomNav } from './components/BottomNav';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.LOGIN);
  const [activeTab, setActiveTab] = useState<'home' | 'assessment' | 'schedule' | 'profile'>('home');

  // --- NAVIGATION HELPER ---
  const navigateTo = (screen: Screen) => {
    setCurrentScreen(screen);
    // Sync bottom tab based on screen
    if (screen === Screen.DASHBOARD) setActiveTab('home');
    if (screen === Screen.ASSESSMENT) setActiveTab('assessment');
    if (screen === Screen.SCHEDULE) setActiveTab('schedule');
    if (screen === Screen.PROFILE) setActiveTab('profile');
  };

  // --- MAIN LAYOUT RENDER ---
  const renderContent = () => {
    switch (currentScreen) {
      case Screen.LOGIN: 
        return <LoginScreen onNavigate={navigateTo} />;
      case Screen.DASHBOARD: 
        return <DashboardScreen onNavigate={navigateTo} />;
      case Screen.ASSESSMENT: 
        return <AssessmentScreen onNavigate={navigateTo} />;
      case Screen.RESULTS: 
        return <ResultsScreen onNavigate={navigateTo} />;
      case Screen.SCHEDULE: 
        return <ScheduleScreen onNavigate={navigateTo} />;
      default: 
        return <DashboardScreen onNavigate={navigateTo} />;
    }
  };

  return (
    <div className="font-sans text-dark max-w-md mx-auto relative shadow-2xl min-h-screen overflow-hidden bg-light">
      {renderContent()}
      
      {currentScreen !== Screen.LOGIN && currentScreen !== Screen.RESULTS && (
        <BottomNav 
          onNavigate={navigateTo} 
          activeTab={activeTab} 
          onTabChange={setActiveTab}
        />
      )}
    </div>
  );
};

export default App;