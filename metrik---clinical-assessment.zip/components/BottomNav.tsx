import React from 'react';
import { Screen, NavigationProps } from '../types';

interface BottomNavProps extends NavigationProps {
  activeTab: 'home' | 'assessment' | 'schedule' | 'profile';
  onTabChange: (tab: 'home' | 'assessment' | 'schedule' | 'profile') => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ onNavigate, activeTab, onTabChange }) => (
  <nav className="fixed bottom-0 left-0 w-full bg-surface/90 backdrop-blur-xl border-t border-gray-200 py-4 px-6 flex justify-between items-center z-50 rounded-t-3xl shadow-[0_-5px_20px_rgba(0,0,0,0.03)]">
    <button 
      onClick={() => onNavigate(Screen.DASHBOARD)}
      className={`flex flex-col items-center gap-1 ${activeTab === 'home' ? 'text-secondary' : 'text-gray-400'}`}
    >
      <span className="material-symbols-rounded text-2xl">grid_view</span>
      <span className="text-[10px] font-bold">Home</span>
    </button>
    
    <button 
      onClick={() => onNavigate(Screen.SCHEDULE)}
      className={`flex flex-col items-center gap-1 ${activeTab === 'schedule' ? 'text-secondary' : 'text-gray-400'}`}
    >
      <span className="material-symbols-rounded text-2xl">calendar_month</span>
      <span className="text-[10px] font-bold">Agenda</span>
    </button>

    {/* Floating Action Button */}
    <button 
      onClick={() => onNavigate(Screen.ASSESSMENT)}
      className="w-14 h-14 bg-black rounded-full flex items-center justify-center -mt-8 shadow-lg shadow-black/30 border-4 border-light transform transition-transform hover:scale-105"
    >
      <span className="material-symbols-rounded text-primary text-3xl">add</span>
    </button>

    <button 
      onClick={() => onTabChange('profile')}
      className={`flex flex-col items-center gap-1 ${activeTab === 'profile' ? 'text-secondary' : 'text-gray-400'}`}
    >
      <span className="material-symbols-rounded text-2xl">person</span>
      <span className="text-[10px] font-bold">Perfil</span>
    </button>
    
    <button className="flex flex-col items-center gap-1 text-gray-400 hover:text-gray-600 transition-colors">
      <span className="material-symbols-rounded text-2xl">settings</span>
      <span className="text-[10px] font-bold">Ajustes</span>
    </button>
  </nav>
);