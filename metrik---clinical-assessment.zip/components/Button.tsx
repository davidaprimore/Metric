import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  fullWidth?: boolean;
  icon?: string;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false, 
  icon,
  className = '',
  ...props 
}) => {
  const baseStyles = "h-14 rounded-2xl font-display font-bold text-sm tracking-wide transition-all active:scale-[0.98] flex items-center justify-center gap-2";
  
  const variants = {
    primary: "bg-primary text-black shadow-neon hover:brightness-105",
    secondary: "bg-black text-primary border border-white/10",
    outline: "border-2 border-black/10 text-black hover:bg-black/5",
    ghost: "bg-transparent text-gray-500 hover:text-black"
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...props}
    >
      {icon && <span className="material-symbols-rounded text-xl">{icon}</span>}
      {children}
    </button>
  );
};