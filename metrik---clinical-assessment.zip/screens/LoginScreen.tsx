import React from 'react';
import { Screen, NavigationProps } from '../types';
import { Button } from '../components/Button';

export const LoginScreen: React.FC<NavigationProps> = ({ onNavigate }) => (
  <div className="min-h-screen bg-dark flex flex-col justify-between p-8 relative overflow-hidden">
    {/* Background Ambience */}
    <div className="absolute top-0 right-0 w-64 h-64 bg-secondary/20 rounded-full blur-[100px] -mr-20 -mt-20"></div>
    <div className="absolute bottom-0 left-0 w-80 h-80 bg-primary/10 rounded-full blur-[120px] -ml-20 -mb-20"></div>

    <div className="flex-1 flex flex-col justify-center items-center z-10">
      <div className="w-20 h-20 bg-primary rounded-3xl flex items-center justify-center mb-8 shadow-neon rotate-3">
        <span className="material-symbols-rounded text-4xl text-black">health_metrics</span>
      </div>
      <h1 className="text-white text-5xl font-display font-bold tracking-tighter text-center mb-2">
        METRIK
      </h1>
      <p className="text-gray-400 text-center text-sm font-medium tracking-widest uppercase">
        Precision Clinical Lab
      </p>
    </div>

    <div className="w-full space-y-4 z-10 mb-8">
      <Button onClick={() => onNavigate(Screen.DASHBOARD)} fullWidth>
        ENTRAR
      </Button>
      <Button variant="secondary" onClick={() => onNavigate(Screen.DASHBOARD)} fullWidth>
        CRIAR CONTA
      </Button>
      <p className="text-center text-gray-600 text-xs mt-6">v2.4.0 • Metrik Technologies</p>
    </div>
  </div>
);